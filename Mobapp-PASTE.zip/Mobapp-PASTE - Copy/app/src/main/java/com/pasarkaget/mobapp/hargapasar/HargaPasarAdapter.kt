package com.pasarkaget.mobapp.hargapasar

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.pasarkaget.mobapp.databinding.ActivityRecyclerBinding

class HargaPasarAdapter(
    private val listBarang: List<HargaPasarData>,
    private val update: (HargaPasarData) -> Unit,
    private val delete: (HargaPasarData) -> Unit
) : RecyclerView.Adapter<HargaPasarAdapter.ViewHolder>() {
    class ViewHolder(val itemViewBinding: ActivityRecyclerBinding) : RecyclerView.ViewHolder(itemViewBinding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ActivityRecyclerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return listBarang.size

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.itemViewBinding.apply {
            tvJudul.text = listBarang[position].nama
            tvDurasi.text = "Rp " + listBarang[position].harga.toString()
            tvSinopsis.text = listBarang[position].deskripsi


            ivEdit.setOnClickListener {
                update.invoke(listBarang[position])

            }

            ivDelete.setOnClickListener{
                delete.invoke(listBarang[position])
            }
        }
    }
}