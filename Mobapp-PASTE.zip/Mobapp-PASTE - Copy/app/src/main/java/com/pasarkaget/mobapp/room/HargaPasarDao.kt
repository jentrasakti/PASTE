package com.pasarkaget.mobapp.room

import androidx.room.*
import com.pasarkaget.mobapp.hargapasar.HargaPasarData

@Dao
interface HargaPasarDao {
    @Query("SELECT * FROM HargaPasarData")
    fun getAllBarang(): List<HargaPasarData>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertBarang(hargaPasarData: HargaPasarData):Long

    @Update
    fun updateBarang(hargaPasarData: HargaPasarData):Int

    @Delete
    fun deleteBarang(hargaPasarData: HargaPasarData):Int
}